/**
 * 
 */

var age=23;
document.write("<div style='color:red; font-size:24px;'>" +
		"외부자바스크립트</div>");
document.write("당신의 나이는"+age+"입니다.");