function insert(){
	location.href="input_notice.html";
}

function bookmark(){
	window.open("bookmark.html", "즐겨찾기 등록", "width=700, height=350, scrollbars=no, resizable=no");
}

$(document).ready(function(){
	
	$("#notice_tr").css({"background":"rgba(200,240,255,0.4)"});
	
});